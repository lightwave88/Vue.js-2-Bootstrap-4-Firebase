console.log('半徑為 r=10 的圓周長為 2 pi r',2*3.15159*10)
console.log('半徑為 r=10 的圓的面積為 pi r ^ 2',3.14159*10*10)
console.log('半徑為 r=10 的球的體積為 4 / 3 pi r ^ 3',0.75*3.14159*10*.10*10)
console.log('半徑為 r=10 的球面的面積為 4 pi r ^ 2',4*3.14159*10*10)

const pi = 3.14159
console.log('半徑為 r=10 的圓周長為 2 pi r', 2 * pi * 10)
console.log('半徑為 r=10 的圓的面積為 pi r ^ 2', pi * 10 * 10)
console.log('半徑為 r=10 的球的體積為 4 / 3 pi r ^ 3', 0.75 * pi * 10 * .10 * 10)
console.log('半徑為 r=10 的球面的面積為 4 pi r ^ 2', 4 * pi * 10 * 10)

pi = 3.14