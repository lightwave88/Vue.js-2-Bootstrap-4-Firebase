const scores = [59,62,38,77,86,12,98]

const result = scores.every((score)=>  score >=60)

console.log(result)