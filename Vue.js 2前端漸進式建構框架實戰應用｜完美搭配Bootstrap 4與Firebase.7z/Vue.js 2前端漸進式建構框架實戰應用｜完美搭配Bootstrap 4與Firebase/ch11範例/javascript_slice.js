let books = [
    'book 1',
    'book 2',
    'book 3',
    'book 4',
    'book 5',
    'book 6'
]
console.log(books.slice(2))
console.log(books.slice(2, 5));
