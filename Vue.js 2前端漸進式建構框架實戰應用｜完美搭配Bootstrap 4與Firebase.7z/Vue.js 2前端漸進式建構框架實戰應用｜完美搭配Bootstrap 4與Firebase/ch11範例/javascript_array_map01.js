const scores = [59,62,38,77,86,12,98]
const result = scores.map((score)=> score + 10)

console.log(result)