import App from './components/App.js'

new Vue({
    el:'#app',
    components:{
        App
    },
    template:'<App/>'
})
