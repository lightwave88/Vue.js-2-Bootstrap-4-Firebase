// ./components/App.js

export default {
    name: 'App',
    template:'<h1>Hello World，歡迎來到 Vue.js 前端世界！</h1>'
};