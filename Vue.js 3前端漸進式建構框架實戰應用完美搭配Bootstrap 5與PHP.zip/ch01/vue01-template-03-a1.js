

// Vue實例的程式碼
const app = Vue.createApp({
    data() {
        return {
            message: "Vue.js 3"
        }
    }

})
app.mount('#app')
