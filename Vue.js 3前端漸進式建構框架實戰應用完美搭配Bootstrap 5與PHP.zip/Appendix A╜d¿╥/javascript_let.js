if(true){
    var x = 10
}
console.log('x = ',x)

if(true){
    let y = 10
    console.log('x = ',--x)
}
console.log('y = ',y)

const foods = ['apple','orange','vegitables','rice']
for(let food of foods){
    console.log('food')
}