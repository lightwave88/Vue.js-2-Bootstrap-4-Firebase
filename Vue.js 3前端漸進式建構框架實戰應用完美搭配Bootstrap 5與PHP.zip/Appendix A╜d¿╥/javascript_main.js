// import SumUp  from './javascript_export04.js'
import * as John from './javascript_export03.js'
console.log(John.BookName)
console.log(John.info())
console.log(John.author)

console.log(John.bookname)
console.log(John.showInfo())



