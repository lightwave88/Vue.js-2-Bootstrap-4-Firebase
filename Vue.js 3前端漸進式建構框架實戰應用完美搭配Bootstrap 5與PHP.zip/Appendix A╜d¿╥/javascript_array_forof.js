const foods = [
    'apple',
    'orange',
    'vegitables',
    'rice'
]
for(let food of foods){
    console.log(food)
}

for(let i=0;i<foods.length;i++){
    console.log(foods[i])
}