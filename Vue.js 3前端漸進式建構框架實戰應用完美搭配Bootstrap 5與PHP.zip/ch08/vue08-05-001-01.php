<?php
$json = '["哲學家看世界的47種方法", "西方哲學史：從蘇格拉底到沙特及其後", "法哲學：自然法研究"]';
$data = json_decode($json);
echo $data[0];
