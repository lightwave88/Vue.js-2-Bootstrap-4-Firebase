<?php
$servername = "localhost";
$dbadmin = "root";
$password = "";
$database = "mis";

// 建立連線
$conn = new mysqli($servername, $dbadmin, $password);

// 檢查否能夠連到資料庫
if ($conn->connect_error) {
	die("連線失敗：" . $conn->connect_error);
}
echo "成功連線";
