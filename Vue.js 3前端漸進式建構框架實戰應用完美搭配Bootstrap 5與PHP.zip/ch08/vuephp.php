<?php
/**
 * Created by PhpStorm.
 * User: shady
 * Date: 3/3/19
 * Time: 5:53 AM
 * https://app.wftutorials.com/Creating-single-page-applications-with-Vue.js-and-PHP
 */
include "./functions.php";
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Vue與PHP測試</title>
</head>

<body>
    <div id="app">
        <h3 class="text-muted">{{ msg.message }} 購物網站</h3>
        <ul class="list-group">
            <li v-for="item in items" :key="item.id" class="list-group-item clearfix">
                <div class="" style="width:100%; display: inline-block;">
                    {{ item.name }}
                    <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right"
                        @click="addToCart(item.id)">加入購物車</a>
                    <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right"
                        @click="removeFromCart(item.id)">移除購物車</a>
                </div>
            </li>
        </ul>
        <p class="lead">購物車內有 {{ itemsCount }} Items</p>
        <a v-if="cardIds.length > 0" href="javascript:void(0)" class="btn btn-sm btn-primary float-right"
            @click="clearProducts()">清空購物車</a>
        <div>
            <span v-if="cardIds.length <=0">購物車內無品項</span>
            <ul>
                <li v-for="item in cardIds" :key="item.id">{{item }}</li>
            </ul>
        </div>


    </div>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script>
    const {
        createApp
    } = Vue

    createApp({
        data() {
            return {
                itemsCount: 0,
                cardIds: [],
                msg: <?php echo get_home_page_data();?>,
                "items": <?php echo get_shop_items();?>,
                products: []
            }
        },
        methods: {
            addToCart(id) {
                console.log(id)
                this.itemsCount++;
                // this.cardIds.push(id);
                this.cardIds.push(this.items[id]['name']);
                console.log(this.items[id]['name']);
                console.log(this.cardIds[id]);
                // this.updateProducts(id);
            },
            removeFromCart(id) {
                console.log(id)
                this.itemsCount--;
                // this.cardIds.push(id);
                this.cardIds.pop(id);
                console.log(this.items[id]['name']);
                console.log(this.cardIds[id]);
                // this.updateProducts(id);
            },
            updateProducts(id) {
                this.productsp[id] = this.items[id];
            },
            clearProducts() {
                if (this.cardIds.length > 0) {
                    this.products = "";
                    this.itemsCount = 0;
                    this.cardIds = [];
                }


            }
        }
    }).mount('#app')
    </script>
</body>
</html?