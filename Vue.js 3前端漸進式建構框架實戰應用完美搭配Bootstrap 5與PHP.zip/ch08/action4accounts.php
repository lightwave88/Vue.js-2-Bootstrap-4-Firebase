<?php
$servername = "localhost";
$dbadmin = "root";
$password = '';
$dbname = "mis";

$connect = new PDO("mysql:host=$servername;dbname=$dbname", $dbadmin, $password);


$received_data = json_decode(file_get_contents("php://input"));
$data = array();
if ($received_data->action == 'fetchall') {
    $query = "
    SELECT * FROM accounts 
    ORDER BY id DESC
    ";
    $statement = $connect->prepare($query);
    $statement->execute();
    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        $data[] = $row;
    }
    echo json_encode($data);
}
if ($received_data->action == 'insert') {
    $data = array(
        ':username' => $received_data->username,
        ':password' => password_hash($received_data->password, PASSWORD_DEFAULT)
    );

    $query = "
    INSERT INTO accounts 
    (username, password) 
    VALUES (:username, :password)
    ";

    $statement = $connect->prepare($query);
    $statement->execute($data);
    $output = array(
        'message' => '已完成新增'
    );

    echo json_encode($output);
}
if ($received_data->action == 'fetchSingle') {
    $query = "
    SELECT * FROM accounts 
    WHERE id = '" . $received_data->id . "'
    ";

    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();

    foreach ($result as $row) {
        $data['id'] = $row['id'];
        $data['username'] = $row['username'];
        $data['password'] = $row['password'];
    }

    echo json_encode($data);
}
if ($received_data->action == 'fetchMatch') {
    $query = "
    SELECT * FROM accounts 
    WHERE username = '" . $received_data->username . "'
    ";

    $statement = $connect->prepare($query);
    $statement->execute();
    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        $data[] = $row;
    }
    echo json_encode($data);
}
if ($received_data->action == 'update') {
    $data = array(
        ':password' => password_hash($received_data->password, PASSWORD_DEFAULT),
        ':id'   => $received_data->id
    );

    $query = "
    UPDATE accounts 
    SET password = :password
    WHERE id = :id
    ";

    $statement = $connect->prepare($query);
    $statement->execute($data);
    $output = array(
        'message' => '資料已更新'
    );

    echo json_encode($output);
}

if ($received_data->action == 'delete') {
    $query = "
    DELETE FROM accounts
    WHERE id = '" . $received_data->id . "'
    ";

    $statement = $connect->prepare($query);

    $statement->execute();

    $output = array(
        'message' => '資料已刪除'
    );

    echo json_encode($output);
}
