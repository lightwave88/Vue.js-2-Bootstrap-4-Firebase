<?php
session_start(); //start the PHP_session function 

$username = $_POST['username'];
$password = $_POST['password'];

$servername = "localhost";
$username = "root";
$password = '';
$dbname = "mis";

$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

$query = $pdo->prepare("SELECT * FROM accounts where username = ? ");

$query->execute(array($_POST['username']));
$user = $query->fetch();


$hash = password_hash("p@ssw0rd", PASSWORD_DEFAULT);
if (password_verify('p@ssw0rd', $hash)) {
	echo 'Password is相同!';
	echo "<br/>";
	echo $hash;
	echo "<br/>";
} else {
	echo 'Invalid 不相同.';
}
// if ($user && password_verify($_POST['pass'], $user['pass']))
if ($user && password_verify($user['password'], $_POST['password'])) {
	echo "Valid ID!";
} else {
	echo "Invalid ID!";
}
