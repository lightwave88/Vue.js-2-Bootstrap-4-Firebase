<?php
$servername = "localhost";
$dbadmin = "root";
$password = "";
$database = "mis";

try {
	$conn = new PDO("mysql:host=$servername;dbname=mis", $dbadmin, $password);
	// set the PDO error mode to exception
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	echo "成功連線";
} catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
