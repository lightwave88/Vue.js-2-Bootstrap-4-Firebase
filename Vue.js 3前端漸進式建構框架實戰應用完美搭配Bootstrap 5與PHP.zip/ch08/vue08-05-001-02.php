<?php
$json = '{
	"title": "資訊刑法",
	"site": "info-criminal.alw"
}';
$data = json_decode($json);
echo $data->title;
echo "\n";
echo $data->site;
