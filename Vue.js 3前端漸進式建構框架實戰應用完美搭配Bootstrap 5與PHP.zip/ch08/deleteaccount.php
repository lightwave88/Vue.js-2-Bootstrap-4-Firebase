<?php
$servername = "localhost";
$username = "root";
$password = '';
$dbname = "mis";

$connect = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

$data = array();
$query = "
SELECT * FROM accounts 
ORDER BY id DESC
";

$statement = $connect->prepare($query);
$statement->execute();
while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
    $data[] = $row;
}

echo json_encode($data);
