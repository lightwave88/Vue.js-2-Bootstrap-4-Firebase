<?php
session_start(); //start the PHP_session function 

$username = $_POST['username'];
$password = $_POST['password'];

$servername = "localhost";
$dbadmin = "root";
$password = '';
$dbname = "mis";

$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $dbadmin, $password);

$query = $pdo->prepare("SELECT * FROM accounts where username = ? ");

$query->execute(array($_POST['username']));
$user = $query->fetch();

// 語法：password_verify(使用者登入時輸入的明碼, 存在資料庫裡經過雜湊的密碼)
if ($user && password_verify($_POST['password'], $user['password'])) {
	$_SESSION["UserName"] = $username;
	// $message = $_SESSION["UserName"] . "登入完成囉！";
	// echo "<script type='text/javascript'>alert('$message');</script>";
	header('Location: vue08-04-001-14.php');
	exit();
} else {
	// echo "登入失敗";
	header('Location: failed.html');
}
