<?php
session_start(); //start the PHP_session function 

$username = $_POST['username'];
$password = $_POST['password'];

$servername = "localhost";
$username = "root";
$password = '';
$dbname = "mis";

$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

$query = $pdo->prepare("SELECT * FROM accounts where username = ? ");

$query->execute(array($_POST['username']));
$user = $query->fetch();


if ($user && password_verify($user['password'], $_POST['password'])) {
	$_SESSION["UserName"] = $username;
	// $message = $_SESSION["UserName"]."登入完成囉！";
	// echo "<script type='text/javascript'>alert('$message');</script>";
	header('Location: vue08-04-001-14.php');
	exit();
} else {
	// echo "登入失敗";
	header('Location: failed.html');
}
