<?php
session_start();
if (!isset($_SESSION['UserName'])) {
    header('Location: index.html');
};
?>
<!DOCTYPE html>
<html lang="zh-HANT-TW">

<head>
    <title>系統管理首頁</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap 5 使用到的 <link>標籤 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .shadow-text {
            font-family: Microsoft JhengHei;

            text-transform: uppercase;

            font-size: 2.2rem;
            font-weight: 700;
            color: #dae0e5;
            text-shadow: 1px 1px 1px #919191,
                1px 2px 1px #919191,
                1px 3px 1px #919191,
                1px 4px 1px #919191,
                1px 5px 1px #919191,
                1px 6px 1px #919191,
                1px 7px 1px #919191,
                1px 8px 1px #919191,
                1px 9px 1px #919191,
                1px 10px 1px #919191,
                1px 18px 6px rgba(16, 16, 16, 0.4),
                1px 22px 10px rgba(16, 16, 16, 0.2),
                1px 25px 35px rgba(16, 16, 16, 0.2),
                1px 30px 60px rgba(16, 16, 16, 0.4);
        }

        .btn-circle {
            width: 30px;
            height: 30px;
            padding: 6px 0px;
            border-radius: 15px;
            text-align: center;
            font-size: 12px;
            line-height: 1.42857;
        }
    </style>
</head>

<body>
    <!-- Vue實例的掛載點 -->
    <div id="app" class="container-fluid mt-2">
        <p class="text-center display-4 shadow-text">使用者帳號管理</p>
        <hr />

        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="input-group">
                        <button class="btn btn-outline-secondary" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-user-plus"></i></button>
                        <button class="btn btn-outline-secondary" type="button" @click="allRecords"><i class="fa-solid fa-list"></i></button>

                        <input type="text" class="form-control" v-model="queryUsername" placeholder="請輸入待查詢的帳號" aria-label="Recipient's username" aria-describedby="button-addon2">
                        <button class="btn btn-outline-secondary" type="button" id="button-addon2" @click="queryAccount"><i class="fa-solid fa-clipboard-question"></i></button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>帳號</th>
                            <th>密碼</th>
                            <th>動作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="account in accounts" :key="account.id">
                            <td>{{ account.username }}</td>
                            <td>{{ account.password }}</td>
                            <td> <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right" data-bs-toggle="modal" data-bs-target="#exampleModal2" @click="updateRecord(account.id)"><i class="fa-sharp fa-solid fa-pen-to-square"></i></a>
                                &nbsp;
                                <a href="javascript:void(0)" class="btn btn-danger btn-sm btn-circle float-right" @click="deleteRecord(account.id)"><i class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer text-body-secondary text-center">
                <a>登出<i class="fa-solid fa-right-from-bracket"></i></a>
            </div>
        </div>

        <!-- Modal 新增 -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">新增使用者帳號</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1">帳號</span>
                            <input type="text" v-model="newUser" class="form-control" placeholder="請輸入帳號名稱" aria-label="Username" aria-describedby="basic-addon1">
                        </div>

                        <div class="input-group mb-3">
                            <input type="text" v-model="newPassword" class="form-control" placeholder="請輸入密碼" aria-label="Recipient's username" aria-describedby="basic-addon2">
                            <span class="input-group-text" id="basic-addon2">密碼</span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">結束</button>
                        <button type="button" class="btn btn-primary" @click="insertRecord">新增</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal 修改 -->
        <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">修改使用者帳號</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1">帳號</span>
                            <input type="text" disabled v-model="editUser" class="form-control" placeholder="請輸入帳號名稱" aria-label="Username" aria-describedby="basic-addon1">
                        </div>

                        <div class="input-group mb-3">
                            <input type="text" v-model="editPassword" class="form-control" placeholder="請輸入密碼" aria-label="Recipient's username" aria-describedby="basic-addon2">
                            <span class="input-group-text" id="basic-addon2">新密碼</span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">結束</button>
                        <button type="button" class="btn btn-primary" @click="updateCurrentRecord">修改</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 使用到的 <script>標籤 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <!-- Vue實例的程式碼 -->
    <script>
        const app = Vue.createApp({
            data() {
                return {
                    accounts: [],
                    queryUsername: '',
                    newUser: '',
                    newPassword: '',
                    editUser: '',
                    editPassword: '',
                }
            },
            methods: {
                allRecords() {
                    console.log('all records ....')
                    axios.post('action4accounts.php', {
                        action: 'fetchall'
                    }).then(response => {
                        this.accounts = response.data;
                    });
                },
                queryAccount() {
                    if (this.queryUsername == "") {
                        alert("請輸入待查詢之帳號")
                    } else {
                        console.log("queery ...", this.queryUsername)
                        axios.post('action4accounts.php', {
                            action: 'fetchMatch',
                            username: this.queryUsername
                        }).then(response => {
                            this.accounts = response.data;
                            this.queryUsername = ''
                        });
                    }
                },
                insertRecord() {
                    if (this.newUser != '' && this.newPassword != '') {
                        axios.post('action4accounts.php', {
                            action: 'insert',
                            username: this.newUser,
                            password: this.newPassword
                        }).then(response => {
                            this.allRecords();
                            this.newUser = '',
                                this.newPassword = ''
                            alert(response.data.message);

                            //Cancel the prompt
                            $('#exampleModal').modal('hide');
                        });

                    } else {
                        alert("資料不完整");
                    }
                },
                updateRecord(id) {
                    axios.post('action4accounts.php', {
                        action: 'fetchSingle',
                        id: id
                    }).then(response => {
                        this.editId = response.data.id;
                        this.editUser = response.data.username;
                        this.editPassword = response.data.password;
                    });
                },
                updateCurrentRecord() {
                    axios.post('action4accounts.php', {
                        action: 'update',
                        password: this.editPassword,
                        id: this.editId
                    }).then(response => {
                        this.allRecords();
                        this.editId = 0;
                        this.editUser = '';
                        this.editPassword = '';
                        alert(response.data.message);
                        //Cancel the prompt
                        $('#exampleModal2').modal('hide');
                    });
                },
            },
            mounted() {
                this.allRecords()
            },
        })
        app.mount('#app')
    </script>
</body>

</html>