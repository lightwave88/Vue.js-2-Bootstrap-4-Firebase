<?php
session_start(); //start the PHP_session function 

$username = $_POST['username'];
$password = $_POST['password'];

include "config4vue.php";
$sql_query_login = "SELECT * FROM accounts where username='$_POST[username]' AND password='$_POST[password]'";

mysqli_query($conn, "SET names 'utf8'");
$result1 = mysqli_query($conn, $sql_query_login) or die("查詢失敗");
if (mysqli_num_rows($result1)) {
	$_SESSION["UserName"] = $username;
	// $message = $_SESSION["UserName"]."登入完成囉！";
	// echo "<script type='text/javascript'>alert('$message');</script>";
	header('Location: vue08-04-001-14.php');
	exit();
} else {
	// echo "登入失敗";
	header('Location: failed.html');
}
