<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mis";

$conn = mysqli_connect($servername, $username, $password, $database);

// 檢查否能夠連到資料庫
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
