<?php

// $host = "localhost"; 
// $username = "root"; 
// $password = "";
// $dbname = "jidca200_linebot"; 

// $servername = "localhost"; /* Host name */
// $database = "jidca200_linebot"; /* User */
// $username = "jidca2004";  /* Password */
// $password = "yahoo7889"; /* Database name */

// $servername="gator3065.hostgator.com";
$servername="localhost";
$username="jidca200_mgt";
$password="yahoo7889";
$database="jidca200_linebot";


// $conn = mysqli_connect($servername, $username, $password);
$con= mysqli_connect($servername,$username,$password,$database);

// $conn=mysqli_connect('localhost', 'jidca2004_jidca200_mgt', 'yahoo7889');// or die ('I cannot connect to the database because: ' . mysqli_connect_error());
// mysqli_select_db ($conn,'jidca2004_jidca200_linebot'); 


// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}