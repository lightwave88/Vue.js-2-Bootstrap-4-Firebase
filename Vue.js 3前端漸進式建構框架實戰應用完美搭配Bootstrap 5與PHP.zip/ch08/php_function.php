<?php
    function get_php_page_data()
    {
        $data = array(
            "message" => "Vue and PHP ",
            "text" => "取自PHP函式的資料"
        );
        return json_encode($data);
    }
