<?php
session_start();
?>
<!doctype html>
<html lang="zh-Hant-TW">

<head>
  <title>系統管理首頁</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>

<body>
  <div>
    <h1>系統管理首頁</h1>
    <a href="logout.php">登出</a>
  </div>
</body>

</html>