<?php
/**
 * Created by PhpStorm.
 * User: shady
 * Date: 3/3/19
 * Time: 10:46 AM
 */

return [
    '1' => [
        "id" => '1',
        "name" => "$400.00 - Dell Laptop - Great Condition"
    ],
    '2' => [
        "id" => '2',
        "name"=>"$60.00 - PS4 Console - Ued One Day"
    ],
    '3' => [
        'id' => '3',
        'name' => '$50.00 - Bunny Rabbit Dol - Pink in color'
    ],
    '4' => [
        'id' => '4',
        'name' => '$750.00 - Travel SuitCase - Plaid'
    ],
    '5' => [
        'id' => '5',
        'name' => '$15000.00 - 16 inch Smart TV - Good Condition'
    ],
    '6' => [
        'id' => '6',
        'name' => '$2450.00 - 19 inch Tall fan - White and Cream available'
    ],
    '7' => [
        'id' => '7',
        'name' => '$900.00 - Black Wallet - Buy one get one free'
    ],
];