<?php
// 取得傳進來的物件 
$data = json_decode(file_get_contents("php://input"), true);
$name = $data['name'];

// 傳出去資料
// PHP的Associate Array，https://www.w3schools.com/php/php_arrays_associative.asp
$output = array(
    'message' => '<p style="font-size:2rem;">已完成新增</p>',
    'message4Alert' => '請繼續購物'
    );

    echo json_encode($output);
?>