<?php
/**
 * Created by PhpStorm.
 * User: shady
 * Date: 3/3/19
 * Time: 5:53 AM
 * https://app.wftutorials.com/Creating-single-page-applications-with-Vue.js-and-PHP
 */
include "./functions.php";
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Vue與PHP測試</title>
    <style>
    .modal-mask {
        position: fixed;
        z-index: 9998;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, .5);
        display: table;
        transition: opacity .3s ease;
    }

    .modal-wrapper {
        display: table-cell;
        vertical-align: middle;
    }

    .modal-container {
        width: 500px;
        margin: 0px auto;
        padding: 20px 30px;
        background-color: #fff;
        border-radius: 2px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, .33);
        transition: all .3s ease;
        font-family: Helvetica, Arial, sans-serif;
    }

    .modal-header h3 {
        margin-top: 0;
        color: #42b983;
    }

    .modal-body {
        margin: 20px 0;
    }

    .modal-default-button {
        float: right;
    }

    /*
         * The following styles are auto-applied to elements with
         * transition="modal" when their visibility is toggled
         * by Vue.js.
         *
         * You can easily play with the modal transition by editing
         * these styles.
         */

    .modal-enter {
        opacity: 0;
    }

    .modal-leave-active {
        opacity: 0;
    }

    .modal-enter .modal-container,
    .modal-leave-active .modal-container {
        -webkit-transform: scale(1.1);
        transform: scale(1.1);
    }
    </style>
</head>

<body>
    <div id="app">
        <h3 class="text-muted">{{ msg.message }} 購物網站</h3>
        <ul class="list-group">
            <li v-for="item in items" :key="item.id" class="list-group-item clearfix">
                <div class="" style="width:100%; display: inline-block;">
                    {{ item.name }}
                    <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right"
                        @click="addToCart(item.id)">加入購物車</a>
                    <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right"
                        @click="removeFromCart(item.id)">移除購物車</a>
                </div>
            </li>
        </ul>
        <p class="lead">購物車內有 {{ itemsCount }} Items</p>
        <a v-if="cardIds.length > 0" href="javascript:void(0)" class="btn btn-sm btn-primary float-right"
            @click="clearProducts()">清空購物車</a>
        <!-- <a v-if="cardIds.length > 0" href="javascript:void(0)" class="btn btn-sm btn-primary float-right"
            @click="writeToDatabase()">結帳</a> -->
        <a v-if="cardIds.length > 0" href="javascript:void(0)" class="btn btn-sm btn-primary float-right"
            @click="showModal()">結帳</a>


        <!-- OKString是利用PHP傳回來的值 -->
        <div v-if="OKString" class="alert alert-danger" role="alert">
            <span v-html="OKString"></span>
        </div>

        <div>
            <span v-if="cardIds.length <=0">購物車內無品項</span>
            <ul>
                <li v-for="item in cardIds" :key="item.id">{{item.name }}</li>
            </ul>
        </div>
        <!-- 結帳的modal視窗 -->
        <div id="modal-template" v-if="checkout">
            <div class="modal-mask">
                <div class="modal-wrapper">
                    <div class="modal-container">
                        <div class="modal-header">
                            <slot name="header">
                                Items in my cart
                            </slot>
                        </div>
                        <div class="modal-body">
                            <slot name="body">
                                <span v-if="cardIds.length <=0">購物車內無品項</span>
                                <ul>
                                    <li v-for="item in cardIds" :key="item.id">{{item.name }}</li>
                                </ul>
                            </slot>
                        </div>

                        <div class="modal-footer">
                            <a v-if="cardIds.length > 0" href="javascript:void(0)"
                                class="btn btn-sm btn-primary float-right" @click="writeToDatabase()">結帳</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script>
    const {
        createApp
    } = Vue

    createApp({
        data() {
            return {
                itemsCount: 0,
                // purchase: {
                //     // id: null,
                //     // name: null
                // },
                cardIds: [],
                msg: <?php echo get_home_page_data();?>, // 呼叫PHP函數
                "items": <?php echo get_shop_items();?>, // 呼叫PHP函數
                products: [],
                isOK: true,
                checkout: false,
                OKString: ""
            }
        },
        methods: {
            addToCart(id) {
                this.OKString = "";
                console.log(id)
                this.itemsCount++;
                // this.cardIds.push(id);
                var purchase = {};
                purchase["id"] = id;
                purchase["name"] = this.items[id]['name'];

                // console.log(itemSelected["name"] + "-" + itemSelected["id"]);
                console.log(purchase);
                this.cardIds.push(purchase);
                console.log(this.cardIds);
                // this.cardIds.push(this.items[id]['name']);
                // console.log(this.items[id]['name']);
                // console.log(this.cardIds[id]);
                // this.updateProducts(id);
            },
            removeFromCart(id) {
                console.log("remove " + id)
                this.itemsCount--;
                // 資料來源：https://www.codingem.com/javascript-remove-specific-element-from-array/
                this.cardIds = this.cardIds.filter(purchase => purchase.id != id);
                console.log(this.cardIds);
                // this.updateProducts(id);
            },
            showModal() {
                this.checkout = true;
            },
            writeToDatabase() {

                // Performing a POST request
                axios.post('./post.php', this.cardIds)
                    // 一定要寫arrow function，不能寫成function(response){}
                    // 否則會無法找到this.isOK之類的this
                    // https://stackoverflow.com/questions/57338914/vuejs-axios-post-request-cant-update-data-binding
                    .then((response) => {
                        console.log(response);

                        if (response.status === 200) {
                            this.isOK = true;
                            this.itemsCount = 0;
                            this.cardIds = [];
                            this.OKString = response.data.message;
                            console.log(this.OKString);
                            this.checkout = false;
                            // 取回 post.php傳回的資料
                            alert(response.data.message4Alert);

                        }
                    }).catch(function(error) {
                        console.log(error);
                    });
            },
            updateProducts(id) {
                this.productsp[id] = this.items[id];
            },
            clearProducts() {
                if (this.cardIds.length > 0) {
                    this.products = "";
                    this.itemsCount = 0;
                    this.cardIds = [];
                }


            }
        }
    }).mount('#app')
    </script>
</body>
</html?